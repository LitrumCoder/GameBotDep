using Telegram.Bot;
using Telegram.Bot.Types.Enums;
using Microsoft.AspNetCore.HttpOverrides;

var builder = WebApplication.CreateBuilder(args);

// Отключаем HTTPS перенаправление
builder.Services.Configure<ForwardedHeadersOptions>(options =>
{
    options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
});

builder.Services.AddControllers().AddNewtonsoftJson();

// Подключение BotToken из конфига или переменных окружения
var botToken = Environment.GetEnvironmentVariable("BOT_TOKEN") ?? builder.Configuration["TelegramBot:Token"];
if (string.IsNullOrEmpty(botToken))
    throw new Exception("Не указан токен бота! Укажите BOT_TOKEN в переменных окружения или TelegramBot:Token в appsettings.json");

// Получаем URL для вебхука
var port = Environment.GetEnvironmentVariable("PORT") ?? "8080";
var baseUrl = Environment.GetEnvironmentVariable("BASE_URL") ?? builder.Configuration["TelegramBot:BaseUrl"];
if (string.IsNullOrEmpty(baseUrl))
{
    // Для Replit используем автоматически сгенерированный URL
    baseUrl = $"https://{Environment.GetEnvironmentVariable("REPL_SLUG")}.{Environment.GetEnvironmentVariable("REPL_OWNER")}.repl.co";
}

builder.Services.AddSingleton<ITelegramBotClient>(_ => new TelegramBotClient(botToken));
builder.Services.AddScoped<TelegramGameBot.Services.IGameService, TelegramGameBot.Services.GameService>();

var app = builder.Build();

// Используем ForwardedHeaders
app.UseForwardedHeaders();

// Настраиваем вебхук при запуске приложения
var botClient = app.Services.GetRequiredService<ITelegramBotClient>();
await botClient.SetWebhookAsync(
    url: $"{baseUrl}/api/webhook",
    allowedUpdates: new[] 
    { 
        UpdateType.Message,
        UpdateType.CallbackQuery
    }
);

Console.WriteLine($"Бот запущен и слушает на {baseUrl}/api/webhook");

app.MapControllers();

// Добавляем простой эндпоинт для проверки работоспособности
app.MapGet("/", () => "Бот работает!");

// Запускаем приложение без HTTPS
await app.RunAsync($"http://0.0.0.0:{port}");
