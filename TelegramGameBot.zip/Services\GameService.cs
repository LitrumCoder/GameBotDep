using Telegram.Bot;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.ReplyMarkups;

namespace TelegramGameBot.Services
{
    public class GameService : IGameService
    {
        private readonly ITelegramBotClient _botClient;

        public GameService(ITelegramBotClient botClient)
        {
            _botClient = botClient;
        }

        public async Task HandleUpdateAsync(Update update)
        {
            try
            {
                switch (update.Type)
                {
                    case UpdateType.Message:
                        await HandleMessageAsync(update.Message!);
                        break;
                    case UpdateType.CallbackQuery:
                        await HandleCallbackQueryAsync(update.CallbackQuery!);
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при обработке обновления: {ex}");
            }
        }

        private async Task HandleMessageAsync(Message message)
        {
            if (message.Text is not { } messageText)
                return;

            var chatId = message.Chat.Id;

            switch (messageText.ToLower())
            {
                case "/start":
                    await SendWelcomeMessage(chatId);
                    break;
                case "/help":
                    await SendHelpMessage(chatId);
                    break;
                default:
                    await _botClient.SendTextMessageAsync(
                        chatId: chatId,
                        text: "Извините, я не понимаю эту команду. Используйте /help для списка доступных команд."
                    );
                    break;
            }
        }

        private async Task HandleCallbackQueryAsync(CallbackQuery callbackQuery)
        {
            await _botClient.AnswerCallbackQueryAsync(callbackQuery.Id);
            // Здесь будет обработка нажатий на кнопки
        }

        private async Task SendWelcomeMessage(long chatId)
        {
            var keyboard = new InlineKeyboardMarkup(new[]
            {
                new []
                {
                    InlineKeyboardButton.WithCallbackData("Начать игру", "start_game"),
                    InlineKeyboardButton.WithCallbackData("Правила", "rules")
                }
            });

            await _botClient.SendTextMessageAsync(
                chatId: chatId,
                text: "👋 Добро пожаловать в игру!\n\nЯ бот для игры в ... (описание игры).\n\nИспользуйте кнопки ниже для начала игры или просмотра правил:",
                replyMarkup: keyboard
            );
        }

        private async Task SendHelpMessage(long chatId)
        {
            var helpText = "Доступные команды:\n" +
                          "/start - Начать игру\n" +
                          "/help - Показать это сообщение\n\n" +
                          "Для начала игры используйте команду /start";

            await _botClient.SendTextMessageAsync(
                chatId: chatId,
                text: helpText
            );
        }
    }
}