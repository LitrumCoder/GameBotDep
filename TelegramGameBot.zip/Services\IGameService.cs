namespace TelegramGameBot.Services
{
    public interface IGameService
    {
        Task HandleUpdateAsync(Telegram.Bot.Types.Update update);
    }
}