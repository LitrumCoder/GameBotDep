namespace TelegramGameBot.Services
{
    public class UserService
    {
        // TODO: Хранение баланса, профилей, истории ставок
        // В будущем — внедрить БД/кэш

        public UserService()
        {
        }

        public Task CreateUserAsync(long userId)
        {
            // Реализация будет позже
            return Task.CompletedTask;
        }

        public Task<int> GetBalanceAsync(long userId)
        {
            // Заглушка — всегда 0
            return Task.FromResult(0);
        }

        public Task ChangeBalanceAsync(long userId, int delta)
        {
            // TODO: Изменить баланс
            return Task.CompletedTask;
        }
    }
}